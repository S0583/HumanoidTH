import trimesh

# 1. ส่วนหัว (กล่อง)
head = trimesh.creation.box(extents=[0.8, 0.8, 0.8])
head.apply_translation([0, 0, 1.8])

# 2. ส่วนลำตัว (กล่อง)
body = trimesh.creation.box(extents=[1.2, 0.8, 1.4])
body.apply_translation([0, 0, 0.7])

# 3. แขนซ้าย และ แขนขวา (ทรงกระบอก)
arm_left = trimesh.creation.cylinder(radius=0.15, height=1.2)
arm_left.apply_translation([-0.8, 0, 0.7])

arm_right = trimesh.creation.cylinder(radius=0.15, height=1.2)
arm_right.apply_translation([0.8, 0, 0.7])

# 4. ขาซ้าย และ ขาขวา (ทรงกระบอก)
leg_left = trimesh.creation.cylinder(radius=0.18, height=1.2)
leg_left.apply_translation([-0.35, 0, -0.6])

leg_right = trimesh.creation.cylinder(radius=0.18, height=1.2)
leg_right.apply_translation([0.35, 0, -0.6])

# 5. รวมทุกชิ้นส่วนเข้าด้วยกันเป็นหุ่นยนต์
robot_parts = [head, body, arm_left, arm_right, leg_left, leg_right]
robot = trimesh.util.concatenate(robot_parts)

# 6. บันทึกและส่งออกเป็นไฟล์ robot.stl
robot.export('robot.stl')

print("สร้างโมเดลหุ่นยนต์ robot.stl เรียบร้อยแล้ว!")