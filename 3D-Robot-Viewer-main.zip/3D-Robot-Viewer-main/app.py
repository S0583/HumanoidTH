import streamlit as st
from streamlit_stl import stl_from_file

# 1. ตั้งชื่อหัวข้อหน้าเว็บ
st.title("🤖 3D Robot & Model Viewer")
st.write("ตัวอย่างการแสดงผลโมเดล 3D ในประเทศไทย")

# 2. แสดงผลไฟล์โมเดล 3D บนหน้าเว็บ (สามารถกดหมุนดูได้)
# (หากคุณมีไฟล์ .stl ให้ใส่ชื่อไฟล์ .stl ตรงนี้)
stl_from_file(
    file_path="robot.stl",
    color="#00aa88",
    material="flat",
    auto_rotate=True
)